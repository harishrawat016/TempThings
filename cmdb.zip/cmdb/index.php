<?php
   session_start();
   if (!(isset($_SESSION['service'])))
   {$_SESSION['service']="ec2";}
 
?>



<!DOCTYPE html>
<html>
<script type="text/javascript">
function OnSelectionChange()
{
	var myPlaceHolder = document.getElementById("idServiceDD");
	var value = myPlaceHolder.options[myPlaceHolder.selectedIndex].text;
	if(value == "Select Service")
	{
		document.getElementById("idResource").placeholder = "Please Select Service";
	}
	else if(value == "EC2")
	{
		document.getElementById("idResource").placeholder = "Name or ID or Account";
	}
	else if(value == "S3")
	{
		document.getElementById("idResource").placeholder = "Bucketname or Account";
	}
	else if(value == "Lambda")
	{
		document.getElementById("idResource").placeholder = "Lambda or Account";
	}
	else
	{
		document.getElementById("idResource").placeholder = "";
	}
	
}
</script>

  <head>
     <title>AWS Inventory</title>
	 <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=0">
     <link rel="stylesheet" type="text/css" href="bootstrap/bootstrap.css">
	 <link rel="stylesheet" type="text/css" href="bootstrap/mycss.css">
     <link rel='icon' type='image/png' href='images/favicon.png' />
     <script type="text/javascript" src="bootstrap/bootstrap.js"></script>
  </head>
<style>
body {margin: 0; padding: 0; overflow-x: hidden;}    
</style>

<body style="background-color:#F0EEEB;" > 
<nav class="navbar navbar-expand-sm bg-dark navbar-dark" style="height:40px;">
	<a class="navbar-brand" href="index.php">
	<img src="images/aws.png" alt="Logo" style="width:50px;height:30px;">
	</a>
	<a class="navbar-brand" href="index.php" style="color:white">Home</a>
</nav>
<br>

<form action="search.php" method="post" >

<div class="row">
	<div class="col-4" ></div>
	<div class="col-2" >
		<select class="form-control" name="serviceDD" id="idServiceDD"  onchange="OnSelectionChange()">
			<option selected="selected">Select Service</option>
			<option>EC2</option>
			<option>S3</option>
			<option>Lambda</option>
		</select>
	</div>
	<div class="col-2" >
		<input type="text" class="form-control mb-2 mr-sm-2" name="resource" id="idResource" placeholder="Please Select Service"></input>
	</div>
	<div class="col-4b bg-warning" ></div>
</div>

<br/>
<div class="row">
	<div class="col-5" ></div>
	<div class="col-1" align="center">
		<button type="submit" class="btn btn-secondary btn-sm" style="width:100%;">Search</button>
	</div>
	<div class="col-1" >
		<button type="button" class="btn btn-secondary btn-sm" style="width:100%;" onclick="window.location.reload();">Reset</button></div>
	<div class="col-5"></div>
</div>

</form>

<div class="footerIndex">
  <p>@ Tata Consultacy Services Limited</p>
</div>


</body>

</html>

