<?php
	session_start();
   $conn = mysqli_connect('localhost','root');
   mysqli_select_db($conn,'inventory');
   $lambda = $_GET['lam'];
   $account = $_GET['acc'];
   $query = " select * from lambdainventory where `ResourceId` = '$lambda' and `AccountId` = ''$account'' " ;
   $result = mysqli_query($conn,$query);
      
?>

<!DOCTYPE html>
<html>
  <head>
     <title>Lambda Inventory</title>
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <link rel="stylesheet" type="text/css" href="bootstrap/bootstrap.css">
	 <link rel="stylesheet" type="text/css" href="bootstrap/mycss.css">
	 <link rel='icon' type='image/png' href='images/favicon.png' />
     <script type="text/javascript" src="bootstrap/bootstrap.js"></script>
  </head>

<style>
body {margin: 0; padding: 0; overflow-x: hidden;}    
</style>

<body style="background-color:#F0EEEB;">
<nav class="navbar navbar-expand-sm bg-dark navbar-dark" style="height:40px;">
	<a class="navbar-brand" href="index.php">
	<img src="images/aws.png" alt="Logo" style="width:50px;height:30px;">
	</a>
	<a class="navbar-brand" href="index.php" style="color:white">Home</a>
</nav>
    
    <center>
<table border="1" width="700" cellpadding="3"> 
<?php

  while ($row = mysqli_fetch_assoc($result))
  {     
		$accId = str_replace("'","",$row["AccountId"]);
      echo '
                <tr>
                    <font face="Arial">
                    <h4>'.strtoupper($row["ResourceId"]).'</h4>
                    </font>
                </tr> 
                <tr>
                    <font face="Arial">
                      <th>Account ID</th>
                    </font>
                    <td>'.$accId.'</td>
                </tr>
				<tr>
                    <font face="Arial">
                      <th>Account Name</th>
                    </font>
                    <td>'.$row["AccountName"].'</td>
                </tr>
                <tr>
                    <font face="Arial">
                      <th>Resource ID</th>
                    </font>
                    <td>'.$row["ResourceId"].'</td>
                </tr> 
				<tr>
                    <font face="Arial">
                      <th>Resource Name</th>
                    </font>
                    <td>'.$row["ResourceName"].'</td>
                </tr> 
                <tr>
                    <font face="Arial">
                      <th>Region</th>
                    </font>
                    <td>'.$row["Region"].'</td>
                </tr> 
                <tr>
                    <font face="Arial">
                      <th>System Owner</th>
                    </font>
                    <td>'.$row["SystemOwner"].'</td>
                </tr> 
                <tr>
                    <font face="Arial">
                      <th>System Custodian</th>
                    </font>
                    <td>'.$row["SystemCustodian"].'</td>
                </tr> 
                <tr>
                    <font face="Arial">
                      <th>Primary IT Contact</th>
                    </font>
                    <td>'.$row["PrimaryItContact"].'</td>
                </tr> 
                <tr>
                    <font face="Arial">
                      <th>HIPPA</th>
                    </font>
                    <td>'.$row["Hippa"].'</td>
                </tr> 
                <tr>
                    <font face="Arial">
                      <th>Cost Center</th>
                    </font>
                    <td>'.$row["CostCenter"].'</td>
                </tr> 
                <tr>
                    <font face="Arial">
                      <th>Last Modified</th>
                    </font>
                    <td>'.$row["LastModified"].'</td>
                </tr> 
                <tr>
                    <font face="Arial">
                      <th>Version</th>
                    </font>
                    <td>'.$row["Version"].'</td>
                </tr>
				<tr>
                    <font face="Arial">
                      <th>Stack Name</th>
                    </font>
                    <td>'.$row["StackName"].'</td>
                </tr> 
                <tr>
                    <font face="Arial">
                      <th>Level1 Business Area</th>
                    </font>
                    <td>'.$row["L1BusinessArea"].'</td>
                </tr> 
                          
               
          ';
   }

 ?>
 </table>
 
 <br><br>
 </center>

<div class="footerIndex">
  <p>@ Tata Consultacy Services Limited</p>
</div>
 
</body>
</html>
