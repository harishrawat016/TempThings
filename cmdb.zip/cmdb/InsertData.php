<?php

$con=mysqli_connect("localhost","root");
mysqli_select_db($con,'inventory');
$file = fopen("C:\\xampp\\htdocs\\myphp\\inventory\\harish.csv","r");
$qDelete = "Delete from myinventory" ;
mysqli_query($con,$qDelete);
$i = 1;
while ($data = fgetcsv($file)){
     if($i > 1){
     $accountID = $data[0];
     $accountType = $data[1];
     $instanceName = $data[2] ;
     $instanceID = $data[3] ;
     $instanceState = $data[4] ;
     $instanceType = $data[5] ;
     $platform = $data[6] ;
     $snowRequestID = $data[7] ;
     $costCenter = $data[8] ;
     $systemOwner = $data[9] ;
     $systemCustodian = $data[10] ;
     $primaryITcontact = $data[11] ;
     $level1BusinessArea = $data[12] ;
     $dataClassification = $data[13] ;
     $HIPAA = $data[14] ;
     $applicationCI = $data[15] ;
     $upTimeHours = $data[16] ;
     $inspector = $data[17] ;
     $subnet = $data[18] ;
     $IPAddress = $data[19] ;
     $az = $data[20] ;
     $amiID = $data[21] ;
     $qUpdate = "insert into myinventory (`Account ID`,`AccountType`,`Instance Name`,`InstanceID`,`InstanceState`,`InstanceType`,`Platform`,`SNOWRequestID`,`CostCenter`,`SystemOwner`,`SystemCustodian`,`PrimaryITContact`,`Level1BusinessArea`,`DataClassification`,`HIPAA`,`ApplicationCI`,`UptimeHours`,`Inspector`,`Subnet`,`IPAddress`,`AZ`,`AMI ID`) values ('$accountID','$accountType','$instanceName','$instanceID','$instanceState','$instanceType','$platform','$snowRequestID','$costCenter','$systemOwner','$systemCustodian','$primaryITcontact','$level1BusinessArea','$dataClassification','$HIPAA','$applicationCI','$upTimeHours','$inspector','$subnet','$IPAddress','$az','$amiID')";
     mysqli_query($con,$qUpdate);
   }
   $i++ ;
}

?>