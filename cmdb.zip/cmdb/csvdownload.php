<?php

session_start();
$conn = mysqli_connect('localhost','root');
mysqli_select_db($conn,'inventory');
$query = $_SESSION['csvQuery'] ;
$result = mysqli_query($conn,$query);

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment;filename=data.csv');
$output = fopen("php://output","w");
fputcsv($output, array('aa','bb','cc','dd'));

while ($row = mysqli_fetch_assoc($result))
{
	fputcsv($output,$row);
}
fclose($output); 
?>
