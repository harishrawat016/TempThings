<?php
	session_start();
	$_SESSION['service']= $_POST['serviceDD'];
	$resourceName = $_POST['resource'] ;
	$query = "";
	$num = 0 ;
	if($_SESSION['service'] == "EC2" and $resourceName != NULL)
	{
		$queryVar = $resourceName;
		$query = " select * from ec2inventory where `InstanceName` like '$queryVar%' or `InstanceId` = '$queryVar' or `AccountId` like '%$queryVar%' or `AccountName` like '%$queryVar%' " ;
	}
	elseif($_SESSION['service'] == "S3" and $resourceName != NULL)
	{
	   $queryVar = $resourceName;
	   $query = " select * from s3inventory where `BucketName` like '%$queryVar%' or `AccountId` like '%$queryVar%' or `AccountName` like '%$queryVar%' " ;
	}
	elseif($_SESSION['service'] == "Lambda" and $resourceName != NULL)
	{
	   $queryVar = $resourceName;
	   $query = " select * from lambdainventory where `ResourceName` like '%$queryVar%' or `AccountId` like '%$queryVar%' or `AccountName` like '%$queryVar%' " ;
	}
	
	if($query != "")
	{
		$conn = mysqli_connect('localhost','root');
		mysqli_select_db($conn,'inventory');
		$result = mysqli_query($conn,$query);
		$num = mysqli_num_rows($result) ;
		$_SESSION['csvQuery'] = $query;
	}
?>

<!DOCTYPE html>
<html>
<script type="text/javascript">
function OnSelectionChange()
{
	var myPlaceHolder = document.getElementById("idServiceDD");
	var value = myPlaceHolder.options[myPlaceHolder.selectedIndex].text;
	if(value == "EC2")
	{
		document.getElementById("idResource").placeholder = "Name or ID or Account";
	}
	else if(value == "S3")
	{
		document.getElementById("idResource").placeholder = "Bucketname or Account";
	}
	else if(value == "Lambda")
	{
		document.getElementById("idResource").placeholder = "Lambda or Account";
	}
	else
	{
		document.getElementById("idResource").placeholder = "";
	}
	
}
</script>

  <head>
     <title>AWS Inventory</title>
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=0">
     <link rel="stylesheet" type="text/css" href="bootstrap/bootstrap.css">
	 <link rel="stylesheet" type="text/css" href="bootstrap/mycss.css">
	 <link rel='icon' type='image/png' href='images/favicon.png' />
     <script type="text/javascript" src="bootstrap/bootstrap.js"></script>
  </head>
<style>
body {margin: 0; padding: 0; overflow-x: hidden;}    
</style>

<body style="background-color:#F0EEEB;">
<nav class="navbar navbar-expand-sm bg-dark navbar-dark" style="height:40px;">
	<a class="navbar-brand" href="index.php">
	<img src="images/aws.png" alt="Logo" style="width:50px;height:30px;">
	</a>
	<a class="navbar-brand" href="index.php" style="color:white">Home</a>
</nav>
 <br/>
  
<form action="search.php" method="post" >
<div class="row">
	<div class="col-4" ></div>
	<div class="col-2 " >
		<select class="form-control" name="serviceDD" id="idServiceDD"  onchange="OnSelectionChange()">
			<option <?php if($_SESSION['service'] == "EC2"){echo 'selected="selected" ';}?>>EC2</option>
			<option <?php if($_SESSION['service'] == "S3"){echo 'selected="selected" ';}?>>S3</option>
			<option <?php if($_SESSION['service'] == "Lambda"){echo 'selected="selected" ';}?>>Lambda</option>
		</select>
	</div>
	<div class="col-2 " >
		<input type="text" class="form-control mb-2 mr-sm-2" name="resource" id="idResource"></input>
		<script>OnSelectionChange();</script>
	</div>
	<div class="col-4 " ></div>
</div>
<br/>
<div class="row">
	<div class="col-5" ></div>
	<div class="col-1" align="center">
		<button type="submit" class="btn btn-secondary btn-sm" style="width:100%;">Search</button>
	</div>
	<div class="col-1" >
		<button type="button" class="btn btn-secondary btn-sm" style="width:100%;" onclick="window.location.href='index.php';">Reset</button></div>
	<div class="col-5"></div>
</div>
</form>

<br/><br/>
<?php
if($num > 0)
{
	echo '<div class="row">
	<div class="col-10" ></div>
	<div class="col-2" >
	<span id="export-menu" class="float-right" ><b>Export to:</b>
	<a class="btn btn-secondary btn-sm" href="csvdownload.php"><img src="images/csv.png" style="width:20px;height:20px;">CSV</a>
	</span>
	</div>
	</div> ' ;
}
?>

<table border="1" width=100% cellpadding="5"> 

<?php

if($query != "")
{
	if($num > 0 and $_SESSION['service'] == "EC2" )
	{
	   echo  '<tr>          
			  <th>Instance ID</th>
			  <th>Instance Name</th>
			  <th>Account Name</th>
			  <th>Account ID</th>
			  <th>System Custodian</th>
			  <th>Primary IT Contact</th>
			  </tr>';
	  while ($row = mysqli_fetch_assoc($result))
	  {     
		$accId = str_replace("'","",$row["AccountId"]);
		echo '<tr>          
				<td><a href ="ec2inventory.php?ec2id='.$row["InstanceId"].'">'.$row["InstanceId"].'</a></td>
				<td>'.$row["InstanceName"].'</td>
				<td>'.$row["AccountName"].'</td>
				<td>'.$accId.'</td>
				<td>'.$row["SystemCustodian"].'</td>
				<td>'.$row["PrimaryItContact"].'</td>
			</tr> 
		';
	  }
	}
	elseif($num > 0 and $_SESSION['service'] == "S3" )
	{
	   echo  '<tr>          
			  <th>Bucket Name</th>
			  <th>Account Name</th>
			  <th>Account ID</th>
			  <th>System Owner</th>
			  <th>System Custodian</th>
			  <th>Primary IT Contact</th>
			  </tr>';
		while ($row = mysqli_fetch_assoc($result))
		{   
			$accId = str_replace("'","",$row["AccountId"]);
		  echo '
					<tr>          
						<td><a href ="s3inventory.php?s3name='.$row["BucketName"].'">'.$row["BucketName"].'</a></td>
						<td>'.$row["AccountName"].'</td>
						<td>'.$accId.'</td>
						<td>'.$row["SystemOwner"].'</td>
						<td>'.$row["SystemCustodian"].'</td>
						<td>'.$row["PrimaryItContact"].'</td>
					</tr> 
				';
		}
	}
	elseif($num > 0 and $_SESSION['service'] == "Lambda")
	{	
		echo  '<tr>     
			  <th>Resource Name</th>
			  <th>Account Name</th>
			  <th>Account ID</th>
			  <th>System Owner</th>
			  <th>System Custodian</th>
			  <th>Primary IT Contact</th>
			  </tr>';
		while ($row = mysqli_fetch_assoc($result))
		{ 
			$accId = str_replace("'","",$row["AccountId"]);
		  echo '
					<tr>          
						<td><a href ="lambdainventory.php?lam='.$row["ResourceName"].'&acc='.$row["AccountId"].'">'.$row["ResourceName"].'</a></td>
						<td>'.$row["AccountName"].'</td>
						<td>'.$accId.'</td>
						<td>'.$row["SystemOwner"].'</td>
						<td>'.$row["SystemCustodian"].'</td>
						<td>'.$row["PrimaryItContact"].'</td>
					</tr> 
				';
		}
	}
	else
	{
		echo	'<center>
				<font face="Arial">
					<h4>'.strtoupper($queryVar).' Not found in Inventory, please check the Name and try again.</h4>
				</font>
				</center> ';
	}
}
else
{
	echo 	'<center>
				<font face="Arial">
					<h4>Please enter some value and try again !!!</h4>
				</font>
			</center> ';
}
?>


</table>
<br>
<?php 
if ($num <= 9)
{
	echo 	'<div class="footerIndex">
			  <p>@ Tata Consultacy Services Limited</p>
			</div>
			';
}
else{
	echo 	'<div class="footerRest">
			  <p>@ Tata Consultacy Services Limited</p>
			</div>
			';
}
?>


</body>
</html>
