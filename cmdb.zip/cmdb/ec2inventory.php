<?php
	session_start();
   $conn = mysqli_connect('localhost','root');
   mysqli_select_db($conn,'inventory');
   $ec2 = $_GET['ec2id'];
   $_SESSION['ec2'] = $ec2;
   $query = " select * from ec2inventory where `InstanceId` = '$ec2' " ;
   $result = mysqli_query($conn,$query);
      
?>

<!DOCTYPE html>
<html>
  <head>
     <title>AWS Inventory</title>
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <link rel="stylesheet" type="text/css" href="bootstrap/bootstrap.css">
	 <link rel="stylesheet" type="text/css" href="bootstrap/mycss.css">
	 <link rel='icon' type='image/png' href='images/favicon.png' />
     <script type="text/javascript" src="bootstrap/bootstrap.js"></script>
  </head>

<style>
body {margin: 0; padding: 0; overflow-x: hidden;}    
</style>

<body style="background-color:#F0EEEB;">
<nav class="navbar navbar-expand-sm bg-dark navbar-dark" style="height:40px;">
	<a class="navbar-brand" href="index.php">
	<img src="images/aws.png" alt="Logo" style="width:50px;height:30px;">
	</a>
	<a class="navbar-brand" href="index.php" style="color:white">Home</a>
</nav>
    
    <center>
<table border="1" width="500" cellpadding="3" cellspacing="0"> 
<?php

  while ($row = mysqli_fetch_assoc($result))
  {   
		$accId = str_replace("'","",$row["AccountId"]); 
      echo '
                <tr>
                    <font face="Arial">
                    <h4>'.strtoupper($row["InstanceName"]).'</h4>
                    </font>
                </tr> 
                 <tr>
                    <font face="Arial">
                      <th>Account ID</th>
                    </font>
                    <td>'.$accId.'</td>
                </tr> 
                <tr>
                    <font face="Arial">
                      <th>Instance Name</th>
                    </font>
                    <td>'.$row["InstanceName"].'</td>
                </tr> 
                <tr>
                    <font face="Arial">
                      <th>Instance ID</th>
                    </font>
                    <td>'.$row["InstanceId"].'</td>
                </tr> 
                <tr>
                    <font face="Arial">
                      <th>Instance Type</th>
                    </font>
                    <td>'.$row["InstanceType"].'</td>
                </tr> 
                <tr>
                    <font face="Arial">
                      <th>OS Type</th>
                    </font>
                    <td>'.$row["OsType"].'</td>
                </tr> 
                <tr>
                    <font face="Arial">
                      <th>System Owner</th>
                    </font>
                    <td>'.$row["SystemOwner"].'</td>
                </tr> 
                <tr>
                    <font face="Arial">
                      <th>System Custodian</th>
                    </font>
                    <td>'.$row["SystemCustodian"].'</td>
                </tr> 
                <tr>
                    <font face="Arial">
                      <th>Primary IT Contact</th>
                    </font>
                    <td>'.$row["PrimaryItContact"].'</td>
                </tr> 
                <tr>
                    <font face="Arial">
                      <th>Subnet ID</th>
                    </font>
                    <td>'.$row["SubnetId"].'</td>
                </tr> 
                <tr>
                    <font face="Arial">
                      <th>Private IP</th>
                    </font>
                    <td>'.$row["PrivateIp"].'</td>
                </tr> 
                <tr>
                    <font face="Arial">
                      <th>Availability Zone</th>
                    </font>
                    <td>'.$row["AvailabilityZone"].'</td>
                </tr> 
                <tr>
                    <font face="Arial">
                      <th>Image ID</th>
                    </font>
                    <td>'.$row["ImageId"].'</td>
                </tr> 
                <tr>
                    <font face="Arial">
                      <th>Security Groups</th>
                    </font>
                    <td>'.$row["SecurityGroups"].'</td>
                </tr> 
                <tr>
                    <font face="Arial">
                      <th>Level1 Business Area</th>
                    </font>
                    <td>'.$row["L1BusinessArea"].'</td>
                </tr> 
                          
               
          ';
   }

 ?>
 </table>
 
 <br><br>
 </center>

<div class="footerIndex">
  <p>@ Tata Consultacy Services Limited</p>
</div>
 
</body>
</html>
